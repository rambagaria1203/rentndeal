enum TextSizes { small, medium, large }
enum LocationStatus {success, locationServiceDisabled, permissionDenied, permissionDeniedForever, error}