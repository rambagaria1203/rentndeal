class ApiConstants {
  ApiConstants._();

  static const String gooleLocationAPIKey = "AIzaSyAk9m23c3al04U5jMesyGtHzODKYdzJfEw";
}