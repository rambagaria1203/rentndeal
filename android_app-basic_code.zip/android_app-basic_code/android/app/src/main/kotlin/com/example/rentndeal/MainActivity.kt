package com.example.rentndeal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
