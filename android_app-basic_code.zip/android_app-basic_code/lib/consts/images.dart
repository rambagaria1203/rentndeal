//icons Login Screen
const icAppLogo = "assets/icons/app_logo.png";
const icSplashBg = "assets/icons/splash_login_registration_background_image.png";
const icFacebookLogo = "assets/icons/facebook_logo.png";
const icTwitterLogo = "assets/icons/twitter_logo.png";
const icGoogleLogo = "assets/icons/google_logo.png";

//Icons Home
const icAdd = "assets/icons/add.png";
const icChat = "assets/icons/chat.png";
const icHome = "assets/icons/home.png";
const icCategories = "assets/icons/categories.png";
const icProfile = "assets/icons/profile.png";

//images Login Screen
const imgBackground = "assets/icons/bg.png";

//images home_screen
const imgSlider1 = "assets/images/slider_1.png";
const imgSlider2 = "assets/images/slider_2.png";
const imgSlider3 = "assets/images/slider_3.png";
const imgSlider4 = "assets/images/slider_4.png";

const imgS1 = "assets/images/s1.jpg";
const imgS2 = "assets/images/s2.jpg";
const imgS3 = "assets/images/s3.jpg";
const imgS4 = "assets/images/s4.jpg";
const imgS5 = "assets/images/s5.jpg";
const imgS6 = "assets/images/s6.jpg";

const imgP1 = "assets/images/p1.jpeg";
const imgP2 = "assets/images/p2.jpeg";
const imgP3 = "assets/images/p3.jpeg";

const imgP6 = "assets/images/p6.jpeg";
// Categories Images
const imgFc1 = "assets/images/fc1.jpeg";
const imgFc2 = "assets/images/fc2.jpeg";
const imgFc3 = "assets/images/fc3.jpeg";
const imgFc4 = "assets/images/fc4.jpeg";
const imgFc5 = "assets/images/fc5.jpeg";
const imgFc6 = "assets/images/fc6.jpeg";
const imgFc7 = "assets/images/fc7.jpeg";
const imgFc8 = "assets/images/fc8.jpeg";
const imgFc9 = "assets/images/fc9.jpeg";


// Profile Section
const icMessages = "assets/icons/messages.png";
const icOrder = "assets/icons/order.png";
const icOrders = "assets/icons/orders.png";

const imgProfile2 = "assets/images/profile_image_joya_ahsan.jpg";