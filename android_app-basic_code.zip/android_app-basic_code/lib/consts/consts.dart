export './colors.dart';
export './images.dart';
export './strings.dart';
export './styles.dart';
export 'package:velocity_x/velocity_x.dart';
export 'package:get/get.dart';
export 'package:rentndeal/widgets_common/applogo_widget.dart';
export 'package:rentndeal/widgets_common/bg_widget.dart';
export 'package:rentndeal/widgets_common/custom_textfield.dart';
export 'package:rentndeal/widgets_common/our_button.dart';
export 'package:rentndeal/consts/lists.dart';
export 'package:rentndeal/views/home_screen/home.dart';
export 'package:rentndeal/controllers/home_controller.dart';
export 'package:rentndeal/views/home_screen/components/feature_button.dart';

export 'package:rentndeal/views/profile_screen/components/details_card.dart';