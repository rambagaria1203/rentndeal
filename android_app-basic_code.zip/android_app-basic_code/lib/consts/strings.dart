// Splash Screen
const appname = "rentndeal";
const appversion = "Version 1.0.0";
const credits = "@rentndeal";

// Login Screen
const email = "Email";
const emailHint = "admin@admin.com";
const password = "Password";
const passwordHint = "*****";
const forgetpassword = "Forget Password";
const retypePassword = "Retype Password";
const retypePasswordHint = "*****";

//Signup Screen
const firstName = " First Name";
const firstNameHint = "rent";
const lastName = "Last Name";
const lastNameHint = "deal";
const phoneNumber = "Mobile Number";
const phoneNumberHint = "xxxxxxxxxx";
const login = "Log in";
const signup = "Sign up";
const createNewAccount = "or, create a new account";
const loginWith = "Log in with";
const privatePolicy = "Private Policy";
const termAndCondition = "Terms and Conditions";
const alreadyHaveAnAccount = "Already have an account? ";

//Home
const home = 'Home', categories = 'Categories',rentsell ='', chat = 'Chat', profile= 'Profile';

//Home_screen
 const searchanything = "Search anything...", 
 todayDeal = "Today's Deal", 
 flashsale = "Flash Sale", 
 topSellers = "Top Sellers", 
 brand = "Brand", 
 topCategories = "Top Categories", 
 featuredCategories = "Featured Categoreis",
 womenDress = "Women Dress",
 girlsWaatches = "Girl Watches",
 mobilePhone = "Mobile Phone",
 boysGlasses = "Boys Glasses",
 tshirt = "TShirts",
 girlsDress = "Girls Dresses",
 featuredProduct = "Featured Product",
 topRated = "Top Rated Products",
 popularProduct = "Popular Products",
 newAdded = "New Added Products";

 // Categories String
 const womenClothing = "Women Clothing";
 const menClothingFashion = "Men Clothing & Fashion";
 const compAccess = "Computer & Accessories";
 const autoMobile = "Automobile";
 const kidToys = "Kids & Toys";
 const sports = "Sports";
 const jewelery = "Jewelery";
 const cellPhone = "Cellphone & Tab";
 const furniture = "Furniture";

 // Items Details String

 const video = "Video",
 reviews = "Reviews",
 sellerPolicy = "Seller Policy",
 returnPolicy = "Return Policy",
 supportPolicy = "Support Policy",
 productsyoumaylike = "Products you may also like";


 // Profile Section
 const wishlist = "My Wishlist",
 logout = "Logout",
 orders = "My Orders",
 messages = "Messages",
 rented = "Rented product";




