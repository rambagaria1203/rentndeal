import 'package:flutter/material.dart';
import 'package:rentndeal/consts/consts.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
bool? isCheck = false;

  @override
  Widget build(BuildContext context) {
    return bgWidget(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body:SingleChildScrollView(
          child: Center(
          child: Column(
            children: [
              (context.screenHeight * 0.05).heightBox,
              applogoWidget(),
              10.heightBox,
              "Join the $appname".text.fontFamily(semibold).white.size(19).make(),
              10.heightBox,

              Column(
                children: [
                  customTextField(title: firstName, hint: firstNameHint),
                  customTextField(title: lastName, hint: lastNameHint),
                  customTextField(title: phoneNumber, hint: phoneNumberHint),
                  customTextField(title: email, hint: emailHint),
                  customTextField(title: password, hint: passwordHint),
                  customTextField(title: retypePassword, hint: retypePasswordHint),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(onPressed: (){}, child: forgetpassword.text.make(),)), 
                    
                   Row(
                    children: [
                      Checkbox(
                        activeColor: redColor,
                        checkColor: whiteColor,

                        value: isCheck, onChanged: (newValue) {
                          setState(() {
                            isCheck= newValue;
                          });
                          
                        }),
                        10.widthBox,
                        Expanded(
                        child:  RichText(text: const TextSpan(
                          children: [
                            TextSpan(text: "I agree to the",style: TextStyle(
                              fontFamily: regular,
                              color: fontGrey,
                            )),
                            TextSpan(text: termAndCondition,style: TextStyle(
                              fontFamily: regular,
                              color: redColor,
                            )),
                            TextSpan(text: " & ",style: TextStyle(
                              fontFamily: regular,
                              color: fontGrey,
                              )),
                            TextSpan(text: privatePolicy,style: TextStyle(
                              fontFamily: regular,
                              color: redColor,
                              )),
                          ]
                        ))
                        )
                  ],
                  ),

                  5.heightBox,
                  ourButton(color: isCheck==true? redColor : lightGrey, title: signup, textColor: whiteColor, onPress: (){}).box.width(context.screenWidth -50).make(),
                   
                  10.heightBox,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      alreadyHaveAnAccount.text.color(fontGrey).make(),
                      login.text.color(redColor).make().onTap(() {
                        Get.back();
                      })
                    ],
                  )
                  ],
                 ), 
                 
                
          ]).box.rounded.white.padding(const EdgeInsets.all(16)).width(context.screenWidth -70).shadowSm.make(),
            
          ),
        ),
      )
    );
  
  }
}