import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:rentndeal/consts/consts.dart';
import 'package:rentndeal/views/category_screen/category_screen.dart';
import 'package:rentndeal/views/chat_screen/chat_screen.dart';
import 'package:rentndeal/views/home_screen/home_screen.dart';
import 'package:rentndeal/views/profile_screen/profile_screen.dart';
import 'package:rentndeal/views/rent_or_sell_screen/rentsell_screen.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    
    //init haome controller
    var controller = Get.put(HomeController());

    var navbarItem = [
      BottomNavigationBarItem(icon: Image.asset(icHome, width: 26,), label: home),
      BottomNavigationBarItem(icon: Image.asset(icCategories, width: 26,), label: categories),
      BottomNavigationBarItem(icon: Image.asset(icAdd, width: 42,), label: rentsell),
      BottomNavigationBarItem(icon: Image.asset(icChat, width: 26,), label: chat),
      BottomNavigationBarItem(icon: Image.asset(icProfile, width: 26,), label: profile),
    ];
var navBody = [
 const HomeScreen(),
 const CategoryScreen(),
 const  RentsellScreen(),
 const ChatScreen(),
 const ProfileScreen(),

];

    return Scaffold(
      body: Column(
        children: [
          Obx(()=>Expanded(child: navBody.elementAt(controller.currentNavIndex.value),)),
        ],
      ),
      bottomNavigationBar: Obx(()=>
        BottomNavigationBar(
          currentIndex: controller.currentNavIndex.value,
          backgroundColor: whiteColor,
          selectedItemColor: redColor,
          selectedLabelStyle: const TextStyle(fontFamily: semibold),
          type: BottomNavigationBarType.fixed,
          items: navbarItem,
          onTap: (value){
            controller.currentNavIndex.value = value;
          },),
      ),
    );
  }
}