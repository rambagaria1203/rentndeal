import 'package:flutter/material.dart';
import 'package:rentndeal/consts/consts.dart';
import 'package:rentndeal/views/auth_screen/login_screen.dart';
import 'package:rentndeal/widgets_common/applogo_widget.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  //Change the screen to Login Screen
  

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

changeScreen(){
    Future.delayed(const Duration(seconds: 3),(){
      // using getx function
      Get.to(()=> const LoginScreen());
      
    });
  }

@override
void initState() {
  changeScreen();
  super.initState(); // This should be the first line in initState.
  
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: redColor,
      body:Center(
        child: Column(
          children: [
            Align(alignment: Alignment.topLeft,child:  Image.asset(icSplashBg,width: 200)),
            5.heightBox,
            applogoWidget(),
            10.heightBox,
            appname.text.fontFamily(bold).size(25).white.make(),
            7.heightBox,
            appversion.text.white.make(),
             const Spacer(),
            credits.text.white.fontFamily(semibold).make(),
            30.heightBox,
          ],
        ),
      )
    );
  }
}
