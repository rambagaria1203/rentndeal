import 'package:flutter/material.dart';
import 'package:rentndeal/consts/consts.dart';

class RentsellScreen extends StatelessWidget {
  const RentsellScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: "Coming soon.....".text.fontFamily(bold).color(darkFontGrey).makeCentered(),
      );
  }
}