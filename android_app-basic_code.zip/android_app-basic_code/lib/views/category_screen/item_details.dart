import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:rentndeal/consts/colors.dart';
import 'package:rentndeal/consts/consts.dart';

class ItemDetails extends StatelessWidget {
  final String? title;
  const ItemDetails({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: lightGrey,
      appBar: AppBar(
        title: title!.text.color(darkFontGrey).fontFamily(bold).make(),
        actions: [
          IconButton(onPressed: (){}, icon: const Icon(Icons.share)),
          IconButton(onPressed: (){}, icon: const Icon(Icons.favorite_outline)),
        ],
      ),
      body: Column(
        children: [
          Expanded(
          child: Padding(
          padding:const EdgeInsets.all(8),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment:CrossAxisAlignment.start ,
              children: [

            // Swiper Section for Item Images
            VxSwiper.builder(
              autoPlay: true,
              height: 350,
              itemCount: 3, 
              aspectRatio: 16/9,
              itemBuilder: (context, index){
              return Image.asset(imgFc5, width:double.infinity, fit: BoxFit.cover);
            }),
                
              10.heightBox,

              // Title and Details Section

              title!.text.size(16).color(darkFontGrey).fontFamily(semibold).make(),
              10.heightBox,

              // Rating Product
              VxRating(
                onRatingUpdate:(Value){}, 
                normalColor: textfieldGrey,
                selectionColor: golden,count: 5,
                size: 25, 
                stepInt: true,),

              // Price Section

              10.heightBox,
              "Rent at \$25\Month".text.color(redColor).fontFamily(bold).size(18).make(),
              10.heightBox,
              "Best Buy \$250".text.color(redColor).fontFamily(bold).size(18).make(),
              15.heightBox,
              Row(
               children: [
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                
                    "Seller".text.white.size(16).fontFamily(semibold).make(),
                  

                  ],
                  ),
                ),
                CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Icon(Icons.message_rounded, color: darkFontGrey,),

                )
               ], 
              ).box.height(65).padding(EdgeInsets.symmetric(horizontal: 16)).color(textfieldGrey).make(),
              
              20.heightBox,
            // Description  Section

            "Product Description".text.color(darkFontGrey).size(16).fontFamily(semibold).make(),
            10.heightBox,
            "This is a dummy item & dummy description here ... when seller will update the description it will be shown here".text.color(darkFontGrey).make(),

            // Button Section
            20.heightBox,
            ListView(
              shrinkWrap: true,
              children: List.generate(
                ItemDetailsButtonList.length, 
                (index) =>ListTile(
                title: "${ItemDetailsButtonList[index]}".text.fontFamily(semibold).color(darkFontGrey).make(),
                trailing: Icon(Icons.arrow_forward),
              )),
            ),
            20.heightBox,

            // products may like
            productsyoumaylike.text.fontFamily(bold).size(18).color(darkFontGrey).make(),
            10.heightBox,

            // Copied this widget from home screen
            SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: List.generate(15, (index) => Column(
                        crossAxisAlignment:CrossAxisAlignment.start ,
                      children: [
                        Image.asset(imgP2, width: 150, fit:BoxFit.cover),
                        5.heightBox,
                        "Laptop 16GB/512GB".text.fontFamily(semibold).color(darkFontGrey).make(),
                        15.heightBox,
                        "Rent \$40/Month".text.color(redColor).fontFamily(bold).size(16).make(),
                        10.heightBox,
                        "Buy \$1200".text.color(redColor).fontFamily(bold).size(16).make(),
                      ],
                      ).box.white.roundedSM.margin(const EdgeInsets.symmetric(horizontal: 4)).padding(const EdgeInsets.all(8)).make()),
                    ),
                  )

             ], 
            )

          ),
            ),
          ),

          SizedBox(
            width: double.infinity,
            height: 60,
            child: ourButton(
              color: redColor,
              onPress: (){},
              textColor: whiteColor, 
              title: "Rent Now"
            ),
          ),
        ],
      ),
      );

    
  }
}