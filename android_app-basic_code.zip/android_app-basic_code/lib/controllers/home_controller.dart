import 'package:rentndeal/consts/consts.dart';

class HomeController extends GetxController {
  var currentNavIndex =0.obs; 
}