import 'package:flutter/cupertino.dart';
import 'package:rentndeal/consts/consts.dart';

Widget applogoWidget(){
  return Image.asset(icAppLogo).box.white.size(140, 140).padding(const EdgeInsets.all(0.5)).rounded.make();
}